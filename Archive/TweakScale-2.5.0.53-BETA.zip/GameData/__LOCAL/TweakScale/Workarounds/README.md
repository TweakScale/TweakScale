# TweakScale :: Workarounds

Due unmaintained and All Rights Reserved Add'Ons causing some breakage, but also due my lack of free time to tackle down these issues and some technical debits still lingering on TweakScale, a series of `Workarounds` will be issue to allow some parts to be used **without** that pesky Yellows and Houstons messages haunting your startup.

Essentially, these patches will buntly remove TweakScale for some parts as they never were patched at all, so TweaskScale's Sanity Checks doesn't have to check them and emit that messages.

You will permantely loose TweakScale features for these parts, however, no matter fixed patches and/or code are applied later. So eventually you will want to get rid of this stunt.

Keep an eye on Announces from the [TweakScale's thread](https://forum.kerbalspaceprogram.com/index.php?/topic/179030-ksp-141-tweakscale-under-lisias-management-24310-2019-1030/) where I will advise for new code and/or fixes that would eliminate the need for these workarounds.

