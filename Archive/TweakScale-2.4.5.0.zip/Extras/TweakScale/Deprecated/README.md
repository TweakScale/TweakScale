# TweakScale :: Deprecated Patches

Since some Add'On maintainers/owners are choosing to internalizing some of the TweakScale patches (thanks!), the TweakScale ones are now not only superfluous, but a nuisance themselves.

This is where I'm moving these patches for historical reasons, as well to keep them around for be used on older versions of that Add'Ons.

Some Add'Ons are, currently, Missed In Action too, and so their patches are useless. These patches will be moved to this directory too as I identify them.

In the unlikely event you need them back, it's recommended to copy them into a customized place on your installment and not on the TweakScale's directory hierarchy. TweakScale suggests `GameData/__LOCAL/TweakScale` .

## License

These patches are licensed to you under:

* [WTFPL](http://www.wtfpl.net), see [here](../LICENSE).
	+ You are free to:
		- Do whatever you want!
	+ Under the following terms:
		- You follow your heart's desire. :)
